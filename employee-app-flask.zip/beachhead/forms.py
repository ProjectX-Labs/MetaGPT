## forms.py
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, IntegerField, SubmitField
from wtforms.validators import DataRequired, Length, ValidationError
from .models import User, Shift
from datetime import datetime

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

    def validate_username(self, field):
        if not User.validate_username(field.data):
            raise ValidationError('Username does not exist.')

class StartShiftForm(FlaskForm):
    submit = SubmitField('Start Shift')

class EndShiftForm(FlaskForm):
    shift_id = IntegerField('Shift ID', validators=[DataRequired()])
    submit = SubmitField('End Shift')

    def validate_shift_id(self, field):
        if not Shift.validate_shift_id(field.data):
            raise ValidationError('Shift ID is invalid or does not exist.')

class EditShiftForm(FlaskForm):
    shift_id = IntegerField('Shift ID', validators=[DataRequired()])
    start_time = StringField('Start Time')  # Assuming the time is entered as a string in a specific format
    end_time = StringField('End Time')      # Same assumption as start_time
    submit = SubmitField('Edit Shift')

    def validate_shift_id(self, field):
        if not Shift.validate_shift_id(field.data):
            raise ValidationError('Shift ID is invalid or does not exist.')

    def validate_start_time(self, field):
        if field.data:
            try:
                datetime.strptime(field.data, '%Y-%m-%d %H:%M:%S')
            except ValueError:
                raise ValidationError('Invalid start time format. Use YYYY-MM-DD HH:MM:SS.')

    def validate_end_time(self, field):
        if field.data:
            try:
                datetime.strptime(field.data, '%Y-%m-%d %H:%M:%S')
            except ValueError:
                raise ValidationError('Invalid end time format. Use YYYY-MM-DD HH:MM:SS.')
