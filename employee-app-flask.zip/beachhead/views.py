## views.py
from flask import Blueprint, request, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from .models import User, Admin, Employee, Shift
from .forms import LoginForm, StartShiftForm, EndShiftForm, EditShiftForm
from .utils import verify_password
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine

# Importing the database URI from a configuration file
from config import DATABASE_URI

engine = create_engine(DATABASE_URI)
Session = sessionmaker(bind=engine)

views = Blueprint('views', __name__)

@views.route('/login', methods=['POST'])
def login():
    form = LoginForm(request.form)
    if form.validate_on_submit():
        session = Session()
        user = session.query(User).filter_by(username=form.username.data).first()
        if user and verify_password(user.password_hash, form.password.data):
            login_user(user)
            session.close()
            return jsonify({'message': 'Logged in successfully.'}), 200
        session.close()
        return jsonify({'message': 'Invalid username or password.'}), 401
    return jsonify({'message': 'Invalid form data.'}), 400

@views.route('/logout')
@login_required
def logout():
    logout_user()
    session = Session()
    session.close()
    return jsonify({'message': 'Logged out successfully.'}), 200

@views.route('/shift/start', methods=['POST'])
@login_required
def start_shift():
    form = StartShiftForm()
    if form.validate_on_submit():
        session = Session()
        if isinstance(current_user, Employee):
            if current_user.start_shift(session):
                session.close()
                return jsonify({'message': 'Shift started successfully.'}), 200
        session.close()
        return jsonify({'message': 'Shift already started or failed to start.'}), 400
    return jsonify({'message': 'Invalid form data.'}), 400

@views.route('/shift/end', methods=['POST'])
@login_required
def end_shift():
    form = EndShiftForm()
    if form.validate_on_submit():
        session = Session()
        if isinstance(current_user, Employee):
            if current_user.end_shift(form.shift_id.data, session):
                session.close()
                return jsonify({'message': 'Shift ended successfully.'}), 200
        session.close()
        return jsonify({'message': 'Shift already ended or failed to end.'}), 400
    return jsonify({'message': 'Invalid form data.'}), 400

@views.route('/shifts', methods=['GET'])
@login_required
def get_shifts():
    session = Session()
    if isinstance(current_user, Admin) or isinstance(current_user, Employee):
        shifts = current_user.get_shifts()
        shifts_data = [{'id': shift.id, 'start_time': shift.start_time.isoformat(), 'end_time': shift.end_time.isoformat() if shift.end_time else None} for shift in shifts]
        session.close()
        return jsonify(shifts_data), 200
    session.close()
    return jsonify({'message': 'Unauthorized access.'}), 403

@views.route('/shift/<int:shift_id>', methods=['PUT'])
@login_required
def edit_shift(shift_id):
    form = EditShiftForm(request.form)
    if form.validate_on_submit():
        session = Session()
        if isinstance(current_user, Admin):
            if current_user.edit_shift(shift_id, session, start_time=form.start_time.data, end_time=form.end_time.data):
                session.close()
                return jsonify({'message': 'Shift updated successfully.'}), 200
        session.close()
        return jsonify({'message': 'Shift not found or unauthorized access.'}), 404
    return jsonify({'message': 'Invalid form data.'}), 400
