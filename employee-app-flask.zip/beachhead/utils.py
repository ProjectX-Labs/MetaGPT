## utils.py
from werkzeug.security import generate_password_hash, check_password_hash

def hash_password(password: str) -> str:
    """
    Hashes a password using werkzeug's generate_password_hash.
    
    :param password: The plain text password to hash.
    :return: A string containing the hashed password.
    """
    if not isinstance(password, str):
        raise TypeError("Password must be a string.")
    if password == "":
        raise ValueError("Password cannot be empty.")
    
    return generate_password_hash(password)

def verify_password(password_hash: str, password: str) -> bool:
    """
    Verifies a password against a given hash using werkzeug's check_password_hash.
    
    :param password_hash: The hash to verify against.
    :param password: The plain text password to verify.
    :return: True if the password matches the hash, False otherwise.
    """
    if not isinstance(password_hash, str) or not isinstance(password, str):
        raise TypeError("Password and hash must be strings.")
    if password_hash == "" or password == "":
        raise ValueError("Password and hash cannot be empty.")
    
    return check_password_hash(password_hash, password)
