from flask import Flask
from flask_login import LoginManager
from flask_socketio import SocketIO
from models import Base, User
from views import views
from sqlalchemy import create_engine
from sqlalchemy.orm import scoped_session, sessionmaker
from config import Config  # Assuming a config.py file exists with a Config class

# Create Flask application instance
app = Flask(__name__)
app.config.from_object(Config)

# Database setup
engine = create_engine(app.config['SQLALCHEMY_DATABASE_URI'])
Base.metadata.bind = engine
Base.metadata.create_all(engine)
db_session = scoped_session(sessionmaker(autocommit=False, autoflush=False, bind=engine))

# Flask-Login setup
login_manager = LoginManager()
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return db_session.query(User).get(int(user_id))

# Flask-SocketIO setup
socketio = SocketIO(app)

# Register blueprints
app.register_blueprint(views, url_prefix='/')

# Error handlers
@app.errorhandler(404)
def not_found_error(error):
    return {'message': 'Resource not found'}, 404

@app.errorhandler(500)
def internal_error(error):
    db_session.rollback()
    return {'message': 'An internal error occurred'}, 500

# Application teardown
@app.teardown_appcontext
def shutdown_session(exception=None):
    db_session.remove()

# Run the Flask application with SocketIO support
if __name__ == '__main__':
    socketio.run(app, debug=app.config['DEBUG'])
