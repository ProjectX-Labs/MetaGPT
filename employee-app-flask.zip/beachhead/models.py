## models.py
from datetime import datetime, timedelta
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from werkzeug.security import generate_password_hash, check_password_hash

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    username = Column(String(64), index=True, unique=True, nullable=False)
    password_hash = Column(String(128), nullable=False)
    role = Column(String(64), nullable=False)
    shifts = relationship('Shift', backref='user')

    def __init__(self, username: str, password: str, role: str):
        self.username = username
        self.set_password(password)
        self.role = role

    def set_password(self, password: str):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)

    def get_shifts(self):
        return self.shifts

class Shift(Base):
    __tablename__ = 'shifts'
    id = Column(Integer, primary_key=True)
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)

    def __init__(self, user_id: int, start_time: datetime, end_time: datetime = None):
        self.user_id = user_id
        self.start_time = start_time
        self.end_time = end_time

    def calculate_duration(self) -> timedelta:
        end_time = self.end_time or datetime.now()
        return end_time - self.start_time

    def calculate_pay(self, rate: float) -> float:
        duration = self.calculate_duration()
        hours = duration.total_seconds() / 3600
        return round(hours * rate, 2)

class Admin(User):
    def manage_user(self, user_id: int, session) -> bool:
        user = session.query(User).get(user_id)
        if user:
            # Perform management operations here
            return True
        return False

    def view_shifts(self, user_id: int, session):
        user = session.query(User).get(user_id)
        if user:
            return user.get_shifts()
        return []

    def edit_shift(self, shift_id: int, session, **kwargs) -> bool:
        shift = session.query(Shift).get(shift_id)
        if shift:
            for key, value in kwargs.items():
                setattr(shift, key, value)
            session.commit()
            return True
        return False

class Employee(User):
    def start_shift(self, session) -> bool:
        new_shift = Shift(user_id=self.id, start_time=datetime.now())
        session.add(new_shift)
        session.commit()
        return True

    def end_shift(self, shift_id: int, session) -> bool:
        shift = session.query(Shift).get(shift_id)
        if shift and shift.user_id == self.id and shift.end_time is None:
            shift.end_time = datetime.now()
            session.commit()
            return True
        return False
