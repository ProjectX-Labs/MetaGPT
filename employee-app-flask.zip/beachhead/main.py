## main.py
from app import app  # Import the Flask app instance directly
from flask_socketio import SocketIO
from config import Config

# Initialize the SocketIO extension with the Flask app instance
socketio = SocketIO(app)

if __name__ == '__main__':
    # Retrieve configuration from the app's config object or use default values
    host = app.config.get('HOST', '0.0.0.0')
    port = app.config.get('PORT', 5000)
    debug = app.config.get('DEBUG', True)
    
    # Run the Flask application with SocketIO support
    socketio.run(app, host=host, port=port, debug=debug)
