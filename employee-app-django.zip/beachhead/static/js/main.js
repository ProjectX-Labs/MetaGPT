// static/js/main.js

// Function to handle CSRF token for AJAX requests
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

// Function to setup AJAX requests with CSRF token
function csrfSafeMethod(method) {
    // These HTTP methods do not require CSRF protection
    return (/^(GET|HEAD|OPTIONS|TRACE)$/.test(method));
}

$.ajaxSetup({
    beforeSend: function(xhr, settings) {
        if (!csrfSafeMethod(settings.type) && !this.crossDomain) {
            xhr.setRequestHeader("X-CSRFToken", getCookie('csrftoken'));
        }
    }
});

// Function to display error messages to the user
function displayError(message) {
    // Implementation to display error messages to the user
    // This could be a modal, toast, or an inline error message
    alert(message); // Placeholder implementation
}

// Function to handle AJAX responses
function handleAjaxResponse(response, onSuccess) {
    if (response.status === 200 || response.status === 201) {
        onSuccess(response.responseJSON);
    } else {
        displayError(`Error: ${response.responseJSON.detail || response.statusText}`);
    }
}

// Function to confirm deletion of an employee
function confirmDelete(employeeId) {
    if (confirm('Are you sure you want to delete this employee?')) {
        $.ajax({
            url: `/employees/${employeeId}/`,
            type: 'DELETE',
            success: function() {
                // On success, remove the employee row from the table
                $(`#employee-${employeeId}`).remove();
            },
            error: function(xhr) {
                // Handle error scenario
                displayError(`Error deleting employee: ${xhr.responseJSON.detail || xhr.statusText}`);
            }
        });
    }
}

// Function to submit the add employee form
$('#addEmployeeForm').submit(function(event) {
    event.preventDefault();
    const formData = $(this).serialize();
    $.ajax({
        url: '/employees/',
        type: 'POST',
        data: formData,
        success: function(employee) {
            // On success, close the modal and add the new employee to the table
            $('#addEmployeeModal').modal('hide');
            addEmployeeToTable(employee);
        },
        error: function(xhr) {
            // Handle error scenario
            displayError(`Error adding employee: ${xhr.responseJSON.detail || xhr.statusText}`);
        }
    });
});

// Function to add employee to the table
function addEmployeeToTable(employee) {
    const employeeRowHtml = createEmployeeRowHtml(employee);
    $('table tbody').append(employeeRowHtml);
}

// Function to submit the edit employee form
$('[id^=editEmployeeForm-]').submit(function(event) {
    event.preventDefault();
    const employeeId = this.id.split('-')[1];
    const formData = $(this).serialize();
    $.ajax({
        url: `/employees/${employeeId}/`,
        type: 'PUT',
        data: formData,
        success: function(employee) {
            // On success, close the modal and update the employee in the table
            $(`#editEmployeeModal-${employeeId}`).modal('hide');
            updateEmployeeInTable(employeeId, employee);
        },
        error: function(xhr) {
            // Handle error scenario
            displayError(`Error updating employee: ${xhr.responseJSON.detail || xhr.statusText}`);
        }
    });
});

// Function to update employee in the table
function updateEmployeeInTable(employeeId, employee) {
    const employeeRowHtml = createEmployeeRowHtml(employee);
    $(`#employee-${employeeId}`).replaceWith(employeeRowHtml);
}

// Function to create the HTML for the employee row
function createEmployeeRowHtml(employee) {
    // Implementation to create the HTML string based on the employee object
    return `
        <tr id="employee-${employee.id}">
            <td>${employee.user.username}</td>
            <td>${employee.user.email}</td>
            <td>${employee.first_name}</td>
            <td>${employee.last_name}</td>
            <td>$${employee.hourly_rate.toFixed(2)}</td>
            <td>
                <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#editEmployeeModal-${employee.id}">
                    Edit
                </button>
                <button type="button" class="btn btn-danger btn-sm" onclick="confirmDelete('${employee.id}')">
                    Delete
                </button>
            </td>
        </tr>
    `;
}
