from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone
import datetime

# Custom User model extending AbstractUser to include is_admin field
class User(AbstractUser):
    is_admin = models.BooleanField(default=False)

# Employee model with a foreign key to the User model
class Employee(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    hourly_rate = models.FloatField(default=0.0)

    def shifts(self):
        return self.shift_set.all()

# Shift model with a foreign key to the Employee model
class Shift(models.Model):
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    duration = models.FloatField(default=0.0)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    pay = models.FloatField(default=0.0)

    def calculate_duration(self):
        if self.start_time and self.end_time:
            self.duration = (self.end_time - self.start_time).total_seconds() / 3600.0
            self.save()
            return self.duration
        return 0.0

    def calculate_pay(self):
        if self.duration == 0.0:
            self.calculate_duration()
        self.pay = self.duration * self.employee.hourly_rate
        self.save()

    def end_shift(self):
        self.calculate_duration()
        self.calculate_pay()

    def save(self, *args, **kwargs):
        if not self.duration or not self.pay:
            self.end_shift()
        super().save(*args, **kwargs)
