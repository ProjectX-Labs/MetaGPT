from rest_framework import serializers
from .models import Employee, Shift, User

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'password', 'email', 'is_admin']
        extra_kwargs = {
            'password': {'write_only': True}
        }

    def create(self, validated_data):
        # Use Django's create_user method to handle password hashing
        user = User.objects.create_user(**validated_data)
        return user

class EmployeeSerializer(serializers.ModelSerializer):
    user = UserSerializer()

    class Meta:
        model = Employee
        fields = ['user', 'first_name', 'last_name', 'hourly_rate']

    def create(self, validated_data):
        user_data = validated_data.pop('user')
        # Directly use the UserSerializer's create method
        user = UserSerializer.create(UserSerializer(), validated_data=user_data)
        employee = Employee.objects.create(user=user, **validated_data)
        return employee

    def update(self, instance, validated_data):
        user_data = validated_data.pop('user')
        user = instance.user

        instance.first_name = validated_data.get('first_name', instance.first_name)
        instance.last_name = validated_data.get('last_name', instance.last_name)
        instance.hourly_rate = validated_data.get('hourly_rate', instance.hourly_rate)
        instance.save()

        user.username = user_data.get('username', user.username)
        user.email = user_data.get('email', user.email)
        if 'password' in user_data:
            user.set_password(user_data['password'])
        user.save()

        return instance

class ShiftSerializer(serializers.ModelSerializer):
    class Meta:
        model = Shift
        fields = ['start_time', 'end_time', 'duration', 'employee', 'pay']

    def create(self, validated_data):
        shift = Shift.objects.create(**validated_data)
        # Ensure calculations are only performed if necessary
        if 'duration' not in validated_data or 'pay' not in validated_data:
            shift.calculate_duration()
            shift.calculate_pay()
        return shift

    def update(self, instance, validated_data):
        instance.start_time = validated_data.get('start_time', instance.start_time)
        instance.end_time = validated_data.get('end_time', instance.end_time)
        # Perform calculations only if the relevant fields have changed
        if 'start_time' in validated_data or 'end_time' in validated_data:
            instance.calculate_duration()
            instance.calculate_pay()
        instance.save()
        return instance
