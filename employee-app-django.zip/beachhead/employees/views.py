from django.shortcuts import render, redirect
from django.contrib.auth.views import LoginView, LogoutView
from rest_framework import viewsets, status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.exceptions import PermissionDenied
from .models import Employee, Shift
from .serializers import EmployeeSerializer, ShiftSerializer

# Custom permission class to handle employee and admin permissions
class IsAdminOrSelf(IsAuthenticated):
    def has_object_permission(self, request, view, obj):
        return request.user.is_admin or obj.user == request.user

class EmployeeViewSet(viewsets.ModelViewSet):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer

    def get_permissions(self):
        if self.action in ['list', 'create']:
            permission_classes = [IsAdminUser]
        else:
            permission_classes = [IsAdminOrSelf]
        return [permission() for permission in permission_classes]

class ShiftViewSet(viewsets.ModelViewSet):
    serializer_class = ShiftSerializer
    permission_classes = [IsAdminOrSelf]

    def get_queryset(self):
        user = self.request.user
        if user.is_admin:
            return Shift.objects.all()
        return Shift.objects.filter(employee__user=user)

    def perform_create(self, serializer):
        employee_id = self.request.data.get('employee')
        if not self.request.user.is_admin and str(employee_id) != str(self.request.user.employee.id):
            raise PermissionDenied("You do not have permission to create shifts for other employees.")
        if not Employee.objects.filter(id=employee_id).exists():
            raise PermissionDenied("Employee does not exist.")
        serializer.save()

# Using Django's built-in authentication views
class CustomLoginView(LoginView):
    template_name = 'login.html'

class CustomLogoutView(LogoutView):
    next_page = 'login'

# The dashboard view is now handled by a separate view that checks for user authentication
def dashboard_view(request):
    if not request.user.is_authenticated:
        return redirect('login')
    context = {
        'user': request.user,
        'is_admin': request.user.is_admin
    }
    if request.user.is_admin:
        return render(request, 'admin_dashboard.html', context)
    else:
        return render(request, 'employee_dashboard.html', context)
