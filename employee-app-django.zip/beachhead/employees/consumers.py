## employees/consumers.py
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from .models import Shift
from .serializers import ShiftSerializer
import json

class EmployeeConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.room_group_name = 'shift_updates'
        # Join room group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        await self.accept()

    async def disconnect(self, close_code):
        # Leave room group
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )

    # Receive message from WebSocket
    async def receive(self, text_data):
        text_data_json = json.loads(text_data)
        shift_id = text_data_json['shift_id']

        # Send message to room group
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'shift_update',
                'shift_id': shift_id
            }
        )

    # Receive message from room group
    async def shift_update(self, event):
        shift_id = event['shift_id']

        # Send message to WebSocket
        shift = await self.get_shift(shift_id)
        await self.send(text_data=json.dumps({
            'shift': shift
        }))

    @database_sync_to_async
    def get_shift(self, shift_id):
        try:
            shift = Shift.objects.get(id=shift_id)
            return ShiftSerializer(shift).data
        except Shift.DoesNotExist:
            return None
