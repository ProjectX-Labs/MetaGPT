## beachhead/urls.py
from django.contrib import admin
from django.urls import path, include
from employees import views as employee_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('employees/', include('employees.urls')),
    # Assuming there is a 'login' view in the employees app for handling user login
    path('login/', employee_views.login_view, name='login'),
    # Assuming there is a 'logout' view in the employees app for handling user logout
    path('logout/', employee_views.logout_view, name='logout'),
    # Assuming there is a 'dashboard' view in the employees app for handling the employee dashboard
    path('dashboard/', employee_views.dashboard_view, name='dashboard'),
]
